/*
* command.h
* Author: Clayton Brown
* Date: Apr 25, 2023
*
* COSC 3750, Homework 10
*
* This code is a structure that records information about the different
* commands that are encountered in the wyshell.c file.
*
*/

#ifndef COMMAND_
#define COMMAND__

struct command
{
   char commandName[200];
   char arguments[16][200];
   int argCount;
   int inputFD;
   int outputFD;
   int errorFD;
   int closeChild;
   int closeParent;
   char *in_file;
   char *out_file;
   char *err_file;
};

#endif

